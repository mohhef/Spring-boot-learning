package com.example.learnJpa.JpaTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
